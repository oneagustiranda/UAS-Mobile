module.exports = app =>{
    const users = require("../controllers/user.controller");
    const userlogin = require("../controllers/userlogin.controller");
    const groups = require("../controllers/group.controller");
    const transaction = require("../controllers/transaction.controller");

    app.get("/api/groups", groups.findAll);

    app.post("/api/groups", groups.create);

    app.delete("/api/groups/:id", groups.delete);

    app.get("/api/groups/:id", groups.findOne);
    app.get("/api/users/group/:id/unpaid", users.findOneByGroupAndUnpaid);

    app.get("/api/users", users.findAll);
    // Mengambil data user yang memiliki username
    app.get("/api/users/:username", users.findOne);
    app.get("/api/users/group/:groupId", users.findWithGroup);
      // Hapus data user yang memiliki username
    app.delete("/api/users/:username", users.delete);

    app.delete("/api/users/group/:id", users.deleteByGroup);
      // Hapus seluruh data
    app.delete("/api/users", users.deleteAll);
    // Membuat user baru
    app.post("/api/users", users.create);

    app.get("/api/user_login", userlogin.getAllUserLogin);
    
    //Update
    app.put("/api/users/:username", users.update);
    app.put("/api/users/group/:id/:username", users.updatePaid);

    
    
    
    //TRANSAKSI
    app.get("/api/transactions", transaction.findAll);
    // Membuat transaksi baru
    app.post("/api/transactions", transaction.create);


  }