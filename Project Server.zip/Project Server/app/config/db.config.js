module.exports={
    HOST:"us-cdbr-iron-east-04.cleardb.net",
    USER:"bf15fd95e4bc8a",
    PASSWORD:"38f455e7",
    DATABASE:"heroku_46d52c139ba1fd9"
};