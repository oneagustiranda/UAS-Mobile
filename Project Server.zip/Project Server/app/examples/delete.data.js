const sql=require("../models/db");
// sql.query("DELETE FROM BOOKS WHEREid='1'",(err,res)=>{
//     if(err){
//         console.log(err);
//     }else{
//         console.log("Data berhasil dihapus:"+res.affectedRows);
//     }
// });

sql.query("TRUNCATE TABLE users",(err,res)=>{
    if(err){
        console.log(err);
    }else{
        console.log("Data berhasil dihapus:"+res.affectedRows);
    }
});