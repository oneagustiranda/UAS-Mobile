// const sql=require("../models/db");
// sql.query("INSERT INTO books VALUES(NULL,'title','desc','perpustakaan.png',current_timestamp());",(err,res)=>{
//     if(err){
//         console.log(err);
//     }else{
//         console.log("Databerhasilditambahkan:"+res.affectedRows);
//     }
// });

// const sql=require("../models/db");
// sql.query("INSERT INTO users VALUES('ervin','Ervin Ahmad Nur Hidayanto','ervin123','ervin.4happy@gmail.com', '087797119047', 0);",(err,res)=>{
//     if(err){
//         console.log(err);
//     }else{
//         console.log("Data berhasil ditambahkan:"+res.affectedRows);
//     }
// });

const sql=require("../models/db");
sql.query("INSERT INTO users VALUES('agus','One Agustiranda','one123','ervin.4happy@gmail.com', '087797119047', 0, 'user.png', 'belum ada grup');",(err,res)=>{
    if(err){
        console.log(err);
    }else{
        console.log("Data berhasil ditambahkan:"+res.affectedRows);
    }
});