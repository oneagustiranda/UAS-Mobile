
//Add collumn
const sql = require("../models/db");
sql.query("ALTER TABLE `groups` ADD `desc` CHAR(255) NOT NULL AFTER `name`;", (err, res) => {
    if (err) {
        console.log("error: ", err);
    } else {
        console.log("Update table berhasil");
    }
});