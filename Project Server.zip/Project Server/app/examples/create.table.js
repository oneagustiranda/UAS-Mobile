// const sql = require("../models/db");
// sql.query("CREATE TABLE books (id int NOT NULL AUTO_INCREMENT, "
//     + "title VARCHAR(255) NOT NULL, description VARCHAR(255), "
//     + "images VARCHAR(255), created_at TIMESTAMP "
//     + "DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(id))",
//     (err, res) => {
//         if (err) {
//             console.log(err);
//         } else {
//             console.log("Table berhasil dibuat");
//         }
//     });


// const sql = require("../models/db");
// sql.query("CREATE TABLE users (username VARCHAR(255) NOT NULL, "
//     + "fullname VARCHAR(255) NOT NULL, password VARCHAR(50) NOT NULL, "
//     + "email VARCHAR(255), no_telp VARCHAR(255), saldo INT(255)"
//     + ", PRIMARY KEY(username))",
//     (err, res) => {
//         if (err) {
//             console.log(err);
//         } else {
//             console.log("Table berhasil dibuat");
//         }
//     });

    const sql = require("../models/db");
sql.query("CREATE TABLE  (username VARCHAR(255) NOT NULL,"
    + "PRIMARY KEY(username))",
    (err, res) => {
        if (err) {
            console.log(err);
        } else {
            console.log("Table berhasil dibuat");
        }
    });