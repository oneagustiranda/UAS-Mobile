const User = require("../models/user.models");


//Mengambil semua data user
exports.findAll = (req, res) => {
    User.getAll((err, data) => {
        if(err){
            res.status(500).send({
                message:
                err.message || "Terjadi Kesalahan"
            });
        } else res.send(data);
    });
};

// Mengambil buku yang memiliki id = id
exports.findOne = (req, res) => {
    User.findByUsername(req.params.username, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({message: `User dengan username ${req.params.username} tidak ditemukan`});
            } else {
                res.status(500).send({message: `Error ketika mengambil user dengan username ${req.params.username}`});
            }
        } else {
            res.send(data);
        }
    });
};

exports.findOneByGroupAndUnpaid = (req, res) => {
    User.findByGroupAndUnpaid(req.params.id, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({message: `User dengan group ${req.params.id} tidak ditemukan`});
            } else {
                res.status(500).send({message: `Error ketika mengambil user dengan group ${req.params.id}`});
            }
        } else {
            res.send(data);
        }
    });
};



// Mengambil buku yang memiliki id = id
exports.findWithGroup = (req, res) => {
    User.findByGroup(req.params.groupId, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({message: `User dengan group ${req.params.groupId} tidak ditemukan`});
            } else {
                res.status(500).send({message: `Error ketika mengambil user dengan group ${req.params.groupId}`});
            }
        } else {
            res.send(data);
        }
    });
};
// Membuat data user baru
exports.create = (req, res) => {
    if (!req.body) {res.status(400).send({message: "Content tidak boleh kosong"});
}
const user = new User({username: req.body.username, fullname: req.body.fullname, password: req.body.password, email: req.body.email, no_telp: req.body.no_telp, saldo: req.body.saldo, img: req.body.img, group_id: req.body.group_id, paid: req.body.paid});
User.create(user, (err, data) => {
    if (err) {res.status(500).send({message:err.message || "Terjadi kesalahan"});
}else {
    res.send(data);
}
});
};// Mengupdate data buku yang memiliki id = id

exports.update = (req, res) => {
    if (!req.body) {
        res.status(400).send({
            message: "Content tidak boleh kosong"
        });
    }
    User.updateByUsername(req.params.username,new User(req.body), (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({message: `User dengan username ${req.params.username} tidak ditemukan`});
            } else {
                res.status(500).send({message: `Error ketika mengupdate user dengan username ${req.params.username}`});
            }
        } else {
            res.send(data);
        }
    });
};// Menghapus buku yang memiliki id = id


exports.updatePaid = (req, res) => {
    if (!req.body) {
        res.status(400).send({
            message: "Content tidak boleh kosong"
        });
    }
    User.updateByGroupAndPaid(req.params.username,req.params.id, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({message: `User dengan group ${req.params.id} dan username ${req.params.username} tidak ditemukan`});
            } else {
                res.status(500).send({message: `Error ketika mengupdate user dengan username ${req.params.id}`});
            }
        } else {
            res.send(data);
        }
    });
};// Menghapus buku yang memiliki id = id


exports.delete = (req, res) => {
    User.removeByUsername(req.params.username, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({
                    message: `User dengan username ${req.params.username} tidak ditemukan`});
                } else {
                    res.status(500).send({
                        message: `Error ketika menghapus user dengan username ${req.params.username}`});
                    }
                } else res.send({ message: `Berhasil menghapus data user!` });
            });
        };
exports.deleteByGroup = (req, res) => {
    User.removeByGroup(req.params.id, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({
                    message: `User dengan group ${req.params.id} tidak ditemukan`});
                } else {
                    res.status(500).send({
                        message: `Error ketika menghapus user dengan group id ${req.params.id}`});
                    }
                } else res.send({ message: `Berhasil menghapus data user!` });
            });
        };
        
// Menghapus semua buku
        
exports.deleteAll = (req, res) => {
    User.removeAll((err, data) => {
        if (err) {
            res.status(500).send({
                message:err.message || "Terjadi kesalahan"});
        }else {
            res.send({ 
                message: `Berhasil menghapus seluruh data buku!` 
            });
        }
    });
};