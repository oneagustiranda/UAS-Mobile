const Transaction = require("../models/transaction.models");


//Mengambil semua data transaksi
exports.findAll = (req, res) => {
    Transaction.getAll((err, data) => {
        if(err){
            res.status(500).send({
                message:
                err.message || "Terjadi Kesalahan"
            });
        } else res.send(data);
    });
};

// Membuat data user baru
exports.create = (req, res) => {
    if (!req.body) {
        res.status(400).send({
            message: "Content tidak boleh kosong"
        });
    }
    const transaction = new Transaction({username: req.body.username, group_id: req.body.group_id, date: req.body.date, status: req.body.status});
    Transaction.create(transaction, (err, data) => {
        if (err) {
            res.status(500).send({
                message:err.message || "Terjadi kesalahan"
            });
        }else{
            res.send(data);
        }
    });
};