const Group = require("../models/group.models");


//Mengambil semua data user
exports.findAll = (req, res) => {
    Group.getAll((err, data) => {
        if(err){
            res.status(500).send({
                message:
                err.message || "Terjadi Kesalahan"
            });
        } else res.send(data);
    });
};

exports.create = (req, res) => {
    if (!req.body) {res.status(400).send({message: "Content tidak boleh kosong"});
}
const group = new Group({name: req.body.name, desc: req.body.desc, amount: req.body.amount, img: req.body.img, endDate: req.body.endDate, period: req.body.period});
Group.create(group, (err, data) => {
    if (err) {res.status(500).send({message:err.message || "Terjadi kesalahan"});
}else {
    res.send(data);
}
});
};


exports.delete = (req, res) => {
    Group.remove(req.params.id, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({
                    message: `Group dengan id ${req.params.id} tidak ditemukan`});
                } else {
                    res.status(500).send({
                        message: `Error ketika menghapus group dengan id ${req.params.id}`});
                    }
                } else res.send({ message: `Berhasil menghapus data group!` });
            });
        };


        // Mengambil buku yang memiliki id = id
exports.findOne = (req, res) => {
    Group.findById(req.params.id, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({message: `Group dengan id ${req.params.id} tidak ditemukan`});
            } else {
                res.status(500).send({message: `Error ketika mengambil group dengan id ${req.params.id}`});
            }
        } else {
            res.send(data);
        }
    });
};
