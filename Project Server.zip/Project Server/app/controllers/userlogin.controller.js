const UserLogin = require("../models/userlogin.models");

//Mengambil semua data user
exports.getAllUserLogin = (req, res) => {
    UserLogin.getAllUserLogin((err, data) => {
        if(err){
            res.status(500).send({
                message:
                err.message || "Terjadi Kesalahan"
            });
        } else res.send(data);
    });
};