const sql = require("./db.js");
const Transaction = function (transaction){
    this.id = transaction.id;
    this.username = transaction.username;
    this.group_id = transaction.group_id;
    this.date = transaction.date;
    this.status = transaction.status;
};

//mengambil semua data transaksi
Transaction.getAll = result => {
    sql.query('SELECT * FROM transaction', (err, res) => {
        if(err){
            console.log("error: ", err);
            result(null, err);
            return;
        }
        console.log("result: ", res);
        result(null, res);
    });
};

// Membuat data transaksi baru
Transaction.create = (newTransaction, result) => {
    console.log(newTransaction);
    sql.query("INSERT INTO transaction (`username`, `group_id`, `date`, `status`) VALUES (?,?,?,?)", [newTransaction.username, newTransaction.group_id, newTransaction.date, newTransaction.status], (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }
        console.log(res);
        console.log("buat user: ", { username: res.insertUsername, ...newTransaction });
        result(null, { username: res.insertUsername, ...newTransaction });
    });
};
module.exports = Transaction;