
const sql = require("./db.js");
const UserLogin = function (userlogin){
    this.usernamelogin = userlogin.usernamelogin;
};

UserLogin.getAllUserLogin = result => {
    sql.query('SELECT * FROM user_login', (err, res) =>{
        if(err){
            console.log("Error: ", err);
            result(null, err);
            return;
        }
        console.log("result: ", res);
        result(null, res);
    });
};

module.exports = UserLogin;