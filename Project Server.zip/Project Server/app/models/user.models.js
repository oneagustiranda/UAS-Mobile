const sql = require("./db.js");
const User = function (user){
    this.username = user.username;
    this.fullname = user.fullname;
    this.password = user.password;
    this.email = user.email;
    this.no_telp = user.no_telp;
    this.saldo = user.saldo;
    this.img = user.img;
    this.group = user.group;
    this.group_id = user.group_id;
    this.paid = user.paid;
};

//mengambil semua data buku
User.getAll = result => {
    sql.query('SELECT * FROM users', (err, res) => {
        if(err){
            console.log("error: ", err);
            result(null, err);
            return;
        }
        console.log("result: ", res);
        result(null, res);
    });
};

// Mengambil user yang memiliki username
User.findByUsername = (username, result) => {
    sql.query(`SELECT * FROM users WHERE username = '${username}'`, (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }if(res.length) {
            console.log(res[0]);
            result(null, res[0]);
            return;
        }result({ kind: "not_found" }, null);
    });
};

// Mengambil user yang memiliki username
User.findByGroup = (groupId, result) => {
    sql.query("SELECT * FROM users WHERE `group_id` = ?", [groupId], (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        
        }result(null, res);
    });
};

// Mengambil user yang memiliki username
User.findByGroupAndUnpaid = (groupId, result) => {
    sql.query("SELECT * FROM users WHERE `group_id` = ? AND `paid` = '0'", [groupId], (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        
        }result(null, res);
    });
};

// Membuat data buku baru
User.create = (newUser, result) => {
    console.log(newUser);
    sql.query("INSERT INTO users (`username`, `fullname`, `password`, `email`, `no_telp`, `saldo`, `img`, `group_id`, `paid`) VALUES (?,?,?,?,?,?,?,?,?)", [newUser.username, newUser.fullname, newUser.password, newUser.email, newUser.no_telp, newUser.saldo, newUser.img, newUser.group_id, newUser.paid], (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }
        console.log(res);
        console.log("buat user: ", { username: res.insertUsername, ...newUser });
        result(null, { username: res.insertUsername, ...newUser });
    });
};
// Mengupdate data buku yang memiliki id = id
User.updateByUsername = ( username, User, result) => {
    sql.query("UPDATE users SET username = ?, fullname = ?, password = ?, email = ?, no_telp = ?, saldo = ?, img = ? WHERE username = ?",[User.username, User.fullname, User.password, User.email, User.no_telp, User.saldo, User.img, username],(err, res) => {
        if (err) {
            console.log("error: ", err);
            result(null, err);
            return;
        }
        if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
        }
        console.log("update user: ", { username: username, ...User });
        result(null, { username: username, ...User });
    });
};


// User.updateByGroupAndPaid = (User, result) => {
//     sql.query("UPDATE `users` SET `paid` = 1 WHERE `group_id` = ?",User.group_id,(err, res) => {
//         if (err) {
//             console.log("error: ", err);
//             result(null, err);
//             return;
//         }
//         if (res.affectedRows == 0) {
//             result({ kind: "not_found" }, null);
//             return;
//         }
//     });
// };
User.updateByGroupAndPaid = (username, id, result) => {
    sql.query("UPDATE users SET paid = 1 WHERE username = '"+username+"' AND `group_id` = '"+id+"'",(err, res) => {
        if (err) {
            console.log("error: ", err);
            result(null, err);
            return;
        }
        if (res.affectedRows == 0) {
            result({ kind: "not_found" }, null);
            return;
        }
        console.log("update user: ", { username: username, ...User });
        result(null, { username: username, ...User });
    });
};


// Menghapus buku yang memiliki id = id
User.removeByUsername = (username, result) => {sql.query("DELETE FROM users WHERE username = ?", username, (err, res) => {
    if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
    }
    if (res.affectedRows == 0) {
        // not found Book with the id
        result({ kind: "not_found" }, null);
        return;
    }
    console.log("hapus buku dengan id: ", id);
    result(null, res);
    });
};

User.removeByGroup = (id, result) => {sql.query("DELETE FROM users WHERE `group_id` = ?", id, (err, res) => {
    if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
    }
    if (res.affectedRows == 0) {
        // not found Book with the id
        result({ kind: "not_found" }, null);
        return;
    }
    console.log("hapus user dengan group id: ", id);
    result(null, res);
    });
};

// Menghapus semua buku
User.removeAll = result => {
    sql.query("DELETE FROM users", (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(null, err);
            return;
        }
        console.log(`Menghapus ${res.affectedRows} user`);
        result(null, res);
    });
};



module.exports = User;
