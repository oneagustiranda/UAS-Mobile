const sql = require("./db.js");
const Group = function (group){
    this.id = group.id;
    this.name = group.name;
    this.desc = group.desc;
    this.amount = group.amount;
    this.endDate = group.endDate;
    this.period = group.period;
};

//mengambil semua data buku
Group.getAll = result => {
    sql.query('SELECT * FROM groups', (err, res) => {
        if(err){
            console.log("error: ", err);
            result(null, err);
            return;
        }
        console.log("result: ", res);
        result(null, res);
    });
};
Group.create = (newGroup, result) => {
    console.log(newGroup);
    sql.query("INSERT INTO `groups` (`name`, `desc`, `amount`, `img`, `endDate`, `period`) VALUES (?,?,?,?,?,?)", [newGroup.name, newGroup.desc, newGroup.amount, newGroup.img, newGroup.endDate, newGroup.period], (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }
        console.log(res);
        console.log("buat group: ", { name: res.insertName, ...newGroup });
        result(null, { name: res.insertName, ...newGroup });
    });
};

Group.remove = (id, result) => {
    sql.query("DELETE FROM groups WHERE id = ?", id, (err, res) => {
    if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
    }
    if (res.affectedRows == 0) {
        // not found Book with the id
        result({ kind: "not_found" }, null);
        return;
    }
    console.log("hapus group dengan id: ", id);
    result(null, res);
    });
};

// Mengambil group yang memiliki id
Group.findById = (id, result) => {
    sql.query(`SELECT * FROM groups WHERE id = '${id}'`, (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }if(res.length) {
            console.log(res[0]);
            result(null, res[0]);
            return;
        }result({ kind: "not_found" }, null);
    });
};

module.exports = Group;
