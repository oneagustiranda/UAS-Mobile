const sql = require("./app/models/db");

const express = require("express");
const bodyParser = require("body-parser");
var cors = require("cors");
var path = require('path');
const app = express();
// parse requests -application/json
app.use(bodyParser.json());
// parse requests -application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
//cors
var cor = cors();
app.use(cor);
//path
app.use(express.static(path.join(__dirname, "./public")));
app.get("/", (req, res) => {
    res.json({ message: "Selamat datang pada matakuliah pemrograman perangkat bergerak" });
});
require("./app/routes/user.routes")(app);
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}.`);
});


var schedule = require('node-schedule');
     
        var j = schedule.scheduleJob('0 0 0 * * *', function(){
        console.log('The answer to life, the universe, and everything!');
        sql.query("UPDATE groups SET dayRemaining = (dayRemaining - 1)",(err, res) => {
            if (err) {
                console.log("error: ", err);
                result(null, err);
            }
            if (res.affectedRows == 0) {
                result({ kind: "not_found" }, null);
            }
            
        });
        });